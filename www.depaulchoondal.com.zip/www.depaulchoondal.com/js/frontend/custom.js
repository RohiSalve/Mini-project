var customScripts = {
    fxHeader: function() {
        var nav_container = $("#main-nav");
        var nav = $(".header");
        nav_container.waypoint({
            handler: function(event, direction) {
                nav.toggleClass('addBg', direction == 'down');
                nav.toggleClass('addBg', direction == 'up');
            },
            offset: function() {
                var scroll = $(window).scrollTop();
                if (scroll >= 10) {
                    nav.addClass('addBg');
                } else {
                    nav.removeClass("addBg");
                }
            },
        });
    },
    profile: function() {
        var portfolio = $('#portfolio');
        var items = $('.items', portfolio);
        var filters = $('.filters li a', portfolio);

        items.imagesLoaded(function() {
            items.isotope({
                itemSelector: '.item',
                layoutMode: 'fitRows',
                transitionDuration: '0.7s'
            });
        });

        filters.click(function() {
            var el = $(this);
            filters.removeClass('active');
            el.addClass('active');
            var selector = el.attr('data-filter');
            items.isotope({
                filter: selector
            });
            return false;
        });
    },
    fancybox: function() {
        // fancybox
        $(".fancybox").fancybox();
    },
    onePageNav: function() {

        $('#mainNav').onePageNav({
            currentClass: 'active',
            changeHash: false,
            scrollSpeed: 950,
            scrollThreshold: 0.2,
            filter: '',
            easing: 'swing',
            begin: function() {
                //I get fired when the animation is starting
            },
            end: function() {
                //I get fired when the animation is ending
                if (!$('#main-nav ul li:first-child').hasClass('active')) {
                    $('.header').addClass('addBg');
                } else {
                    $('.header').removeClass('addBg');
                }

            },
            scrollChange: function($currentListItem) {
                //I get fired when you enter a section and I pass the list item of the section
                if (!$('#main-nav ul li:first-child').hasClass('active')) {
                    $('.header').addClass('addBg');
                } else {
                    $('.header').removeClass('addBg');
                }
            }
        });

        $("a[href='#top']").click(function() {
            $("html, body").animate({
                scrollTop: 0
            }, "slow");
            return false;
        });
        $("a[href='#basics']").click(function() {
            $("html, body").animate({
                scrollTop: $('#services').offset().top - 75
            }, "slow");
            return false;
        });
    },
    owlSlider: function() {
        var owl = $("#owl-demo");
        owl.owlCarousel();
        // Custom Navigation Events
        $(".next").click(function() {
            owl.trigger('owl.next');
        })
        $(".prev").click(function() {
            owl.trigger('owl.prev');
        })
    },
    bannerHeight: function() {
        var bHeight = $(".banner-container").height();
        $('#da-slider').height(bHeight);
        $(window).resize(function() {
            var bHeight = $(".banner-container").height();
            $('#da-slider').height(bHeight);
        });
    },
    waySlide: function() {
        /* Waypoints Animations
		   ------------------------------------------------------ */


    },
    fitText: function() {
        setTimeout(function() {
            $('h1.responsive-headline').fitText(1.2, {
                minFontSize: '16px',
                maxFontSize: '30px'
            });
        }, 100);
    },
    init: function() {
        customScripts.fxHeader();
        //customScripts.onePageNav();
        customScripts.profile();
        customScripts.fancybox();
        customScripts.owlSlider();
        customScripts.waySlide();
        customScripts.fitText();
        customScripts.bannerHeight();
    }
}
$('document').ready(function() {
    customScripts.init();
    $('.carousel').carousel();
});
$(function() {
    customScripts.fxHeader();
});


$(document).ready(function() {

    if ($(".owl-demo.former_principal").length) {
        //TESTIMONIALS SLIDER
        var owl = $(".owl-demo.former_principal");
        owl.owlCarousel({
            itemsCustom: [
                [0, 5]
            ],
            navigation: false,
            pagination: false,
            vertical: true,
            items: 5
        });
        owl.trigger('owl.play', 6000);
        jQuery('.owl-controls').addClass('container');
    }

    if ($(".owl-demo.former_manager").length) {
        //TESTIMONIALS SLIDER
        var owl = $(".owl-demo.former_manager");
        owl.owlCarousel({
            itemsCustom: [
                [0, 5]
            ],
            navigation: false,
            pagination: false,
            vertical: true,
            items: 5
        });
        owl.trigger('owl.play', 4000);
        jQuery('.owl-controls').addClass('container');
    }

    if ($(".owl-demo.former_bursar").length) {
        //TESTIMONIALS SLIDER
        var owl = $(".owl-demo.former_bursar");
        owl.owlCarousel({
            itemsCustom: [
                [0, 5]
            ],
            navigation: false,
            pagination: false,
            vertical: true,
            items: 5
        });
        owl.trigger('owl.play', 9000);
        jQuery('.owl-controls').addClass('container');
    }

    if ($('.widget_recent_news.newsSlide').length) {
        if ($('.widget_recent_news.newsSlide li').length > 2) {
            $(".widget_recent_news.newsSlide").bootstrapNews({
                newsPerPage: 2,
                autoplay: true,
                pauseOnHover: true,
                navigation: false,
                direction: 'up',
                newsTickerInterval: 3500,
                onToDo: function() {}
            });
        }
    }
    if ($('#principalDesk').length) {
        $("#principalDesk span.close").click(function() {
            $("#principalDesk").remove();
        });
    }
});

$(document).ready(function() {
    if ($("#googleMap").length || $("#googleMapLocation").length) {
        function initialize() {
            var mapLatLng = new google.maps.LatLng(10.618652, 76.096385);
            if ($("#googleMap").length) {

                var map = new google.maps.Map(document.getElementById('googleMap'), {
                    center: mapLatLng,
                    zoom: 16
                });
            } else {
                var map = new google.maps.Map(document.getElementById('googleMapLocation'), {
                    center: mapLatLng,
                    zoom: 19
                });
            }
            var marker = new google.maps.Marker({
                position: mapLatLng,
                map: map,
                title: 'De-Paul English Medium Higher Secondary School'
            });
            var circleOptions = {
                strokeColor: '#004884',
                strokeOpacity: 0.8,
                strokeWeight: 2,
                fillColor: '#A2C4E0',
                fillOpacity: 0.35,
                map: map,
                center: mapLatLng,
                radius: 50
            };
            circle = new google.maps.Circle(circleOptions);
        }
        google.maps.event.addDomListener(window, 'load', initialize);


    }
});